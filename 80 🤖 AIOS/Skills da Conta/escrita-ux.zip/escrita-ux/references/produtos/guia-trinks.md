# Guia de escrita da Trinks

> **Só para produtos da Trinks.** Em qualquer outro projeto, este guia não vale: use apenas as regras gerais da skill.

## Índice
1. Fontes e precedência
2. Interface: regras do checklist de UX writing
3. Voz e tom da marca
4. A Trinks no feminino e o tratamento
5. Gramática e formatação
6. Termos da Trinks
7. Pontos em aberto entre os documentos

## 1. Fontes e precedência
Resumo de dois documentos internos da Trinks (originais no GLADIS, em `50 🗃️ Fontes Brutas/`):
- **Checklist de UX Writing:** regras para textos de interface.
- **Guia de Redação e Linguagem:** voz da marca, gramática e formatação para toda a comunicação.

**Na interface, o checklist prevalece.** O guia de redação vale para o que o checklist não cobre e para comunicação (e-mail, WhatsApp, central de ajuda).

## 2. Interface: regras do checklist de UX writing

**Geral**
- Sem erro de digitação, gramática ou concordância. Direto, sem jargão.
- Títulos e subtítulos dizem o objetivo da página ou seção.
- CTAs claros, curtos e que levam ao próximo passo.
- Mesmo termo em todo o conteúdo; tom consistente.
- Parágrafos curtos, listas e quebras de linha.
- Linguagem neutra de gênero. Sem itálico.

**Títulos de pop-ups e telas:** só a primeira letra maiúscula; sem pontuação.

**Menção a campos, botões e telas no texto:** entre aspas. Ex.: No campo "Valor unitário", informe...

**Botões de resposta de pop-up**
- Verbo no infinitivo que mostra a ação ("Concluir").
- **O mesmo verbo do título** (título "Cadastrar...", botão "Cadastrar").
- Nunca "Sim" e "Não".
- Só a primeira letra maiúscula.
- Uma palavra, a menos que precise de mais para ficar claro ("Adicionar item").

**Botões em geral:** verbo no infinitivo; só a primeira letra maiúscula; sem negrito; sem ponto ou exclamação; no máximo 5 palavras (quanto menos, melhor); nada de "Ver mais" ou "Olhar".

**Filtros:** botão primário "Aplicar"; secundário "Redefinir".

**Select e input:** sem dois-pontos depois do rótulo.

**Colunas:** maiúscula só na primeira palavra.

**Feedback positivo**
- A pessoa precisa ter certeza de que a ação foi concluída.
- Nada genérico ("Ação realizada com sucesso").
- Um verbo ou particípio: "Cupom criado com sucesso", "Despesa cadastrada com sucesso".
- Sem artigo ("Cupom criado", não "O cupom foi criado").
- Com o ícone adequado.

**Mensagem de erro:** simples e leve, sem alarme; diz claramente o que fazer para corrigir; com ícone.

**Feedback negativo:** com ponto final; sem termos capacitistas (nunca "Inválido"); com ícone.

**Faixa de informações adicionais:** só o essencial para entender a etapa; sem redundância; sem sobrecarga de texto; só o contexto que não dá para mostrar de outro jeito; hierarquia visual para o principal; informação secundária fica para outro momento.

**Dias da semana:** por extenso; abreviação só em relatórios e calendários.

**Telefone (placeholder):** (00) 00000-0000.

**Linguagem neutra e inclusiva:** evitar artigos; termos neutros ("cliente", "pessoa"); evitar pronomes de gênero ("ele", "ela").

**Testar o texto:** leitura em voz alta, perguntar se dava para simplificar, provocar um erro e ver se a pessoa entende, perguntar o que o botão vai fazer; priorizar botões, erros, onboarding e feedback de sucesso; **mobile primeiro, sempre**.

## 3. Voz e tom da marca
**Voz: convidativa, coloquial e ousada.**
- **Convidativa:** calorosa, acolhedora, amigável. Expressões: "Faça parte", "Junte-se a nós", "Venha fazer parte da nossa comunidade".
- **Coloquial:** como conversa entre pessoas próximas. Expressões: "Tudo certo por aí?", "Bora fazer acontecer", "Você vai amar essa novidade".
- **Ousada:** confiança e energia. Expressões: "Com a gente, você faz acontecer", "Diga adeus às horas desperdiçadas".

**Como isso entra na interface:** com moderação. Em boas-vindas, conquistas, novidades e estados vazios de primeiro uso, a voz pode aparecer ("Bora", "Você vai amar"). Em erro, pagamento, dados e tarefas de rotina, clareza primeiro. Frases de venda e o slogan ("Bora dar um up") não entram em telas de tarefa.

**Regras de linguagem**
- **Modos verbais:** indicativo e imperativo. Evitar o condicional ("Se você se dedicasse..." → "Quando você se dedica...").
- **Tempo verbal:** presente ("Os recursos simplificam", não "simplificarão").
- **Sem diminutivos** e sem excesso de reduções ("rapidinha", "pra", "pro").
- **Positiva:** evitar começar com "Não" ou "Infelizmente". Ex.: "Ops, esqueceu a senha? Você pode recuperar aqui." em vez de "Não foi possível identificar a sua senha."
- **Voz ativa.** Em comunicação institucional, "nós" representa o time.
- **Emojis** (só em comunicação, em momentos leves e de boas-vindas): 😉 😄 😎 🙌 ✅ 🤳 ⏱️ ⌛. Na interface, use ícone, não emoji.

## 4. A Trinks no feminino e o tratamento
- **Sempre "a Trinks":** "A Trinks conta com...", "A Trinks resolve!". Nunca "o Trinks". "O sistema da Trinks" e "o aplicativo da Trinks" estão certos.
- **Tratamento:** "você", nunca "senhor" ou "doutor". Respeito sem distância; bom humor sem passar do limite profissional.
- **Pelo nome:** em comunicação, chamar a pessoa pelo nome, com vírgula no vocativo ("Oi, Carla!").
- **Inclusiva:** respeita todas as pessoas.

## 5. Gramática e formatação
| Item | Regra | Certo | Errado |
|---|---|---|---|
| Títulos, subtítulos, botões | Sem pontuação final | Formas de pagamento | Formas de pagamento. |
| Interrogação e exclamação | Uma só | Oi, Carla! | Oi, Carla!!! |
| Aspas | Para nomes de telas, campos, termos técnicos e expressões fixas | Acesse "Formas de pagamento" | Acesse Formas de pagamento |
| Vocativo | Entre vírgulas | Oi, João, tudo bem? | Oi João tudo bem? |
| Substantivo comum | Minúscula quando não é o nome da funcionalidade | suas contas a pagar | suas Contas a Pagar |
| Números | Algarismos; mil e milhão por extenso nos grandes redondos | 3 formas; 3 mil; 2,6 milhões | três formas |
| Horários | 0 a 23 + "h" colado; minutos logo depois; sem "min" | 7h; 10h30; 18h | 19:30; 19 h; 17h15 min |
| Datas em tabela | DD/MM/AAAA | 05/10/2026 | 5/10/26 |
| Datas no texto | Por extenso, mês em minúscula | 25 de setembro de 2019 | 25/09/2019 |
| Primeiro dia do mês | Ordinal | 1º de setembro | 01 de setembro |
| Dias 2 a 9 | Com zero na forma numérica | 02/10 | 2/10 |
| Cidade e estado | Barra | Rio de Janeiro/RJ | Rio de Janeiro-RJ |
| Funcionalidades e adicionais | Nome próprio, maiúscula | Nota Fiscal, Conta Digital, Clube de Assinaturas | nota fiscal (quando é a funcionalidade) |
| Siglas | Maiúsculas e com hífen oficial | NF, NFs, NF-e, NFS-e, NFC-e | nf, NFe, NFE, NFCE |
| Planos | Nome próprio | Plano Mensal, Plano Semestral, Plano Anual | plano mensal |
| Cargos | Minúscula | gerente, diretor | Gerente (no meio da frase) |
| Áreas da empresa | Maiúscula em cada palavra | Marketing, Vendas | marketing |
| E-mail | Com hífen | e-mail | email |
| Negrito | Ideia principal da frase, não palavra solta; sem negrito na pontuação; nunca com sublinhado ou link | | |
| Itálico | Não usar (leitores de tela e dislexia) | | |
| Links | Dizem o que será visto | Ver tutoriais de agenda | Clique aqui |
| Imagens e vídeos | Legenda ou texto alternativo quando têm conteúdo; decorativos passam despercebidos | | |

## 6. Termos da Trinks
| Use | Sentido |
|---|---|
| Negócios de beleza e bem-estar | O segmento dos clientes |
| Empreendedor, empresário, dono do negócio | Quem está por trás do negócio |
| Recursos | As funcionalidades e ferramentas |
| Gestão | O que a Trinks faz |
| Ágil | Gestão mais rápida, sem repetir "economizar tempo" |
| Automatizar, simplificar | Como a Trinks reduz o trabalho operacional |
| Crescimento, crescer, ir além, prontos para crescer | O resultado que a Trinks gera |
| A parceira | Como a Trinks se apresenta |
| Bora, dar um up, junte-se, faça parte | Expressões da voz coloquial e convidativa (comunicação) |

Antes de usar o nome de uma funcionalidade, confirme o nome exato no projeto ou com a Julia.

## 7. Pontos em aberto entre os documentos
Quando um destes aparecer no texto, aplique a escolha indicada e avise a Julia.

| Tema | Divergência | Escolha padrão |
|---|---|---|
| Primeiro dia do mês | O checklist dá o exemplo "1 de setembro"; o guia pede "1º" | **1º**, como no guia (o checklist também fala em numeral ordinal) |
| Artigos | O checklist pede para evitar artigos; o guia pede "a Trinks", no feminino | Evitar artigos que marcam gênero de pessoas e em feedbacks; manter "a Trinks" |
| Linguagem neutra | O checklist pede linguagem neutra; o guia tem exemplos como "Obrigado", "ajudá-lo", "empreendedor" | Na interface, neutra ("Agradecemos", "ajudar você", "pessoa empreendedora" quando couber) |
| Começar com "Não" | O guia pede para evitar; o checklist pede feedback negativo com ponto final, sem proibir o "não" | Evitar no início quando houver alternativa clara |
| Botões | Uma palavra (pop-up) e até 5 palavras (geral) | Pop-up: uma palavra, salvo necessidade; outros botões: até 5 |
